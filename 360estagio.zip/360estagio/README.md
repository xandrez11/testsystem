# projeto estagio

Sistema para gerenciamento de estágios em hospitais, com check-in de alunos e validação por preceptores. Desenvolvido com **Spring Boot** seguindo o padrão **MVC** (Model-View-Controller).

## 🎯 Objetivo

- Registro de presença via check-in.
- Validação por preceptores.
- Organização de estágios por especialidade e período.

## 🧱 Arquitetura MVC

- **Model**: Entidades como `Usuario`, `Estagio`, `Checkin`.
- **Repository**: Acesso ao banco via `JpaRepository`.
- **Service**: Regras de negócio (ex: validação de presença).
- **Controller**: Endpoints REST.

## 🗂️ Entidades Principais

- `Usuario`: Aluno (CPF).
- `Preceptor` / `LocalPreceptor`.
- `Estagio`, `Especialidade`, `EstagioAluno`.
- `Checkin`, `Periodo`, `PeriodoEspecialidade`.

## ✅ Funcionalidades

- Check-in de aluno.
- Validação de presença.
- Listagem de estágios por especialidade.
- Cadastro de períodos e vagas.

## 🚀 Tecnologias

- Java 17, Spring Boot, Spring Data JPA, REST


## 👥 Integrantes do Grupo

- Ana Cláudia de Souza Silva  
- Eliane Marques da Silva  
- Geliel Vinícius Dias Santos  
- Willma Avelar da Silva  
- José Matheus Pereira dos Prazeres