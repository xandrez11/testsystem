package com.sexta_6._estagio.model;
import jakarta.persistence.*;

@Entity

public class Estagio {
        @Id
        private String idEstagio;

        @ManyToMany
        @JoinColumn(name = "idEspecialidade")
        private Especialidade especialidade;
        
        @ManyToMany
        @JoinColumn(name = "idPreceptor")
        private Preceptor preceptor;

        private String dataInicio;
        private String dataFim;
        private String status;

}

