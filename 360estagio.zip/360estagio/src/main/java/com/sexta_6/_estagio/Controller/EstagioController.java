package com.sexta_6._estagio.Controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/estagios")

public class EstagioController {
        
    @GetMapping("/disponiveis")
    public List<Estagio> listarEstagiosDisponiveis(@RequestParam String idEspecialidade) {
        return estagioService.listarEstagiosDisponiveis(idEspecialidade);
    }

}

