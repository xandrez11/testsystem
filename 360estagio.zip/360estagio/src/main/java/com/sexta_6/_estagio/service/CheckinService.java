package com.sexta_6._estagio.service;
import org.springframework.stereotype.Service;


public class CheckinService {
        public void realizarCheckin(String cpfAluno, String idEstagio) {

        }

        public boolean validarCheckin(String idCheckin, boolean validado) {

            return validado;
        }
}

