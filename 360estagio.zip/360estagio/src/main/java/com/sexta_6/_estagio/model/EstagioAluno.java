package com.sexta_6._estagio.model;
import jakarta.persistence.*;

@Entity

public class EstagioAluno {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToMany
    @JoinColumn(name = "idEstagio")
    private Estagio estagio;

    @ManyToMany
    @JoinColumn(name = "idAluno")
    private Usuario aluno;

    private String status;

}
