package com.sexta_6._estagio.model;
import jakarta.persistence.*;

@Entity

public class PeriodoEspecialidade {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
     private String id;
    
    @ManyToMany
    @JoinColumn(name = "id_periodo")
    private Periodo periodo;
    
    @ManyToMany
    @JoinColumn(name = "id_especialidade")
    private Especialidade especialidade;

    private int cargaHoraria;

}