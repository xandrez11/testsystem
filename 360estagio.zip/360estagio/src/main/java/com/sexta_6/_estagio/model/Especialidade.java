package com.sexta_6._estagio.model;
import jakarta.persistence.*;
import java.util.List;

@Entity
public class Especialidade {
        @Id
        private String id;
        private String nome;
        @ManyToMany(mappedBy = "especialidade")
        private List<Estagio> estagios;

        @ManyToMany(mappedBy = "especialidade")
        private List<PeriodoEspecialidade> periodos;
}

