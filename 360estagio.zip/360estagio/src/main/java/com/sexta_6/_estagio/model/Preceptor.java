package com.sexta_6._estagio.model;
import jakarta.persistence.*;
import java.util.List;

@Entity

public class Preceptor {
        @Id
        private String cpf;
        private String nome;
        @ManyToMany(mappedby = "preceptor")
        private List<Estagio> estagios;

}

