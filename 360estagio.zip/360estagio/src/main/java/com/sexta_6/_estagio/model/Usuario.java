package com.sexta_6._estagio.model;
import jakarta.persistence.*;
  
@Entity
public class Usuario {
        @Id
          private String cpf;
        private String nome;
        private String email;
        @ManyToMany
          @JoinColumn(name = "idEstagio")
          private Estagio estagio
}

