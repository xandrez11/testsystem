package com.sexta_6._estagio.Repository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/periodo-especialidades")

public class PeriodoEspecialidadeController{

    @GetMapping
    public List<PeriodoEspecialidade> ListarPeriodosEspecialidades() {
        return periodoEspecialidadeRepository.findAll();
    }

    @PostMapping
    public PeriodoEspecialidade criarPeriodoEspecialidade(@RequestBody PeriodoEspecialidade periodoEspecialidade) {
        return periodoEspecialidadeRepository.save(periodoEspecialidade);
    }
}