package com.sexta_6._estagio.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalPreceptorRepository extends JpaRepository<LocalPreceptor, String> {

}

