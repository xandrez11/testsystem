package com.sexta_6._estagio.model;
import jakarta.persistence.*;
import java.list.List;

@Entity

public class Periodo {
    @Id
    private String id;
    private String nome;
    private String descricao;
    private String cargaHorariaObrigatoria;

    @OneToMany(mappedBy = "periodo")
   private List<PeriodoEspecialidade> especialidades;

}