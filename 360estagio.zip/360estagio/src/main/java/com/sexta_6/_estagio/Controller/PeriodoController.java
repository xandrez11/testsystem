package com.sexta_6._estagio.Repository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/periodos")

public class PeriodoController{
    
    @GetMapping
    public List<Periodo> listarPeriodos() {
        return periodoRepository.findAll();
    }
    
    @PostMapping
    public Periodo criarPeriodo(@RequestBody Periodo periodo) {
        return periodoRepository.save(periodo);
    }


}
    
      

