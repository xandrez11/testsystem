package com.sexta_6._estagio.model;
import jakarta.persistence.*;

@Entity

public class LocalPreceptor {
       @Id
        private String id;

       @ManyToMany
       @JoinColumn(name = "idPreceptor")
       private Preceptor preceptor;

        private String local;
        private String status;

}

