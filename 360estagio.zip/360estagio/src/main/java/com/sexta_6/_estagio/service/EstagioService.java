package com.sexta_6._estagio.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.ArrayList;


public class EstagioService {
        public List<Estagio> listarEstagiosDisponiveis(String idEspecialidade) {

            return new ArrayList<>();
        }
}

