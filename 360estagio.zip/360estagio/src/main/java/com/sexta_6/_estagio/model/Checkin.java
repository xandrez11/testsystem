package com.sexta_6._estagio.model;
import jakarta.persistence.*;

@Entity

public class Checkin {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToMany
    @JoinColumn(name = "idUsuario")
    private Usuario usuario;

    @ManyToMany
    @JoinColumn(name = "idEstagio")
    private Estagio estagio;

    private String dataHoraCheckin;
    private boolean valido;

}
