package com.sexta_6._estagio.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/checkin")

public class CheckinController {
        
    @PostMapping("/fazer")
    public void fazerCheckin(@RequestParam String cpfAluno, @RequestParam String idEstagio) {
        checkinService.realizarCheckin(cpfAluno, idEstagio);
    }
    
    @PostMapping("/validar")
    public void validarCheckin(@RequestParam String idCheckin, @RequestParam boolean validado) {
        checkinService.validarCheckin(idCheckin, validado);
    }
}
